-- Indice secondario sul nome degli artisti
CREATE INDEX indice_nomi_artisti ON artisti (nome);